﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Kinect;
using Rug.Osc;
using System.IO;

namespace KinectV2OSC.Model.Network
{
    public class MessageBuilder
    {
        
        public OscMessage BuildJointMessage(Body body, KeyValuePair<JointType, Joint> joint)
        {
            //string[] lines = { "First line", "Second line", "Third line" };
            //string mydocpath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments); 
             
            
            //var csv = new StreamWriter();
            var address = String.Format("/bodies/{0}/joints/{1}", body.TrackingId, joint.Key);
            var position = joint.Value.Position;
            //Console.WriteLine(address); //was none
            //var newLine = String.Format("/bodies/{0}/joints/{1}", address, (Convert.ToString(position.X)));
            //csv.AppendLine(newLine); 
            /*
            Console.Write(address);
            Console.Write(",");
            Console.Write(Convert.ToString(position.X));
            Console.Write(",");
            Console.Write(Convert.ToString(position.Y));
            Console.Write(",");
            Console.Write(Convert.ToString(position.Z)); //was none
            Console.WriteLine(".");
            */ 

            using (StreamWriter stream = new FileInfo("D:\\tt.txt").AppendText())
            {
                stream.Write(address);
                stream.Write(",");
                stream.Write(Convert.ToString(position.X));
                stream.Write(",");
                stream.Write(Convert.ToString(position.Y));
                stream.Write(",");
                stream.Write(Convert.ToString(position.Z)); //was none
                //stream.WriteLine(".");
                stream.Flush();
                stream.Close(); 
            }

                /*
                using (StreamWriter outputFile = new StreamWriter(Path.Combine(mydocpath, "WriteLines.txt")))

                {

                    //outputFile.WriteLine(".");
                    File.AppendAllText(@"C:\Users\Swasth Wrutha\Documents\WriteLines.txt", address );
                    File.AppendAllText(@"C:\Users\Swasth Wrutha\Documents\WriteLines.txt", ",");
                    File.AppendAllText(@"C:\Users\Swasth Wrutha\Documents\WriteLines.txt", Convert.ToString(position.X));
                    File.AppendAllText(@"C:\Users\Swasth Wrutha\Documents\WriteLines.txt", ",");


                }
                */


                /*
                using (StreamWriter outputFile = new StreamWriter(Path.Combine(mydocpath, "WriteLines.txt")))
                {
                    outputFile.Write(address);
                    outputFile.Write(",");
                    outputFile.Write(Convert.ToString(position.X));
                    outputFile.Write(",");
                    outputFile.Write(Convert.ToString(position.Y));
                    outputFile.Write(",");
                    outputFile.Write(Convert.ToString(position.Z)); //was none
                    outputFile.WriteLine(".");

                }

                TextWriter tw = new StreamWriter("file.txt");
                tw.WriteLine(address, position.X, position.Y, position.Z, joint.Value.TrackingState.ToString());
                tw.Close();
                */
                // File.AppendAllLines(@"C:\Data]file.txt", new[] { "my test content" }); 

                //System.Diagnostics.Debug.WriteLine(address);
                return new OscMessage(address, position.X, position.Y, position.Z, joint.Value.TrackingState.ToString());
        }

        public OscMessage BuildHandMessage(Body body, string key, HandState state, TrackingConfidence confidence)
        {
            var address = String.Format("/bodies/{0}/hands/{1}", body.TrackingId, key);
            //System.Diagnostics.Debug.WriteLine(address);
            return new OscMessage(address, state.ToString(), confidence.ToString());
        }
    }
}
